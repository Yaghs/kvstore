/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   main.c
 * Author: student
 *
 * Created on October 15, 2023, 11:01 PM
 */

#include <stdio.h>
#include "kvstore.h"
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    initialize(); // Initialize the key-value store

    for (int i = 1; i < argc; i++) {
        char *command = strtok(argv[i], ","); // Splits the command and arguments using a comma as a separator this is how we call the commands on the terminals ex: ./fskv p,10,ramzi
        // these are a list of commands needed to call the functions stored in kvstore.c
        if (command != NULL) {
            if (strcmp(command, "p") == 0) {
                // Put command logic
                int key = atoi(strtok(NULL, ",")); // Extracts the key 
                char *value = strtok(NULL, ""); // Extract the value, including spaces
                put(key, value); // Add the key-value pair to the store
                
            } else if (strcmp(command, "g") == 0) {
                // Gets command logic
                int key = atoi(strtok(NULL, ",")); // Extracts the key
                char *result = get(key);
                if (result != NULL) {
                    printf("%d,%s\n", key, result); // Prints the key and value
                } else {
                    printf("%d not found\n", key); // Prints an error if the key is not found
                }
            } else if (strcmp(command, "d") == 0) {
                // Delete command logic
                int key = atoi(strtok(NULL, ",")); // Extract the key
                int successfull_deletion = delete(key);
                if (successfull_deletion) {
                    printf("Deleted %d\n", key); // Prints a confirmation message
                } else {
                    printf("%d not found\n", key); // Prints an error if the key is not found
                }
            } else if (strcmp(command, "c") == 0) {
                clear(); // Clears all key-value pairs in the store
            } else if (strcmp(command, "a") == 0) {
                print_all(); // Prints all key-value pairs in the store
            } else {
                printf("Bad command: %s\n", argv[i]); // Handle unrecognized commands
            }
        }
    }

    return 0;
}







