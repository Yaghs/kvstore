#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kvstore.h"

// Define a constant for the database file
#define DATABASE_FILE "database.txt"

// Define the data structure to store key-value pairs
KeyValue key_value_pairs[100]; // Assuming a maximum of 100 pairs the value just in case
int num_pairs = 0; // Tracks the number of pairs stored

// Loads key-value pairs from the database file
void load_data() {
    FILE *file = fopen(DATABASE_FILE, "r"); // Opens the file "database.txt" for reading
    if (file != NULL) {
        // Reads the file line by line, extracting key-value pairs
        while (fscanf(file, "%d,%99[^\n]", &key_value_pairs[num_pairs].key, key_value_pairs[num_pairs].value) == 2) {
            num_pairs++; // Increments the pair count as data is loaded
        }
        fclose(file); // Closes the file after reading
    }
}

// Saves key-value pairs to the database file
void save_data() {
    FILE *file = fopen(DATABASE_FILE, "w"); // Opens the file "database.txt" for writing (overwrite if it exists)
    if (file != NULL) {
        // Writes key-value pairs to the file, one pair per line
        for (int i = 0; i < num_pairs; i++) {
            fprintf(file, "%d,%s\n", key_value_pairs[i].key, key_value_pairs[i].value);
        }
        fclose(file); // Close the file after writing
    }
}

void initialize() {
    load_data(); // Load data from the database file at initialization
}

int put(int key, const char *value) {
    if (num_pairs < 100) {
        // Add a new key-value pair to the array and save the data
        key_value_pairs[num_pairs].key = key;
        strncpy(key_value_pairs[num_pairs].value, value, MAX_VALUE_LENGTH);
        num_pairs++;
        save_data(); // Save data to the database file
        return 1; // Success
    }
    return 0; // Database is full
}

char *get(int key) {
    for (int i = 0; i < num_pairs; i++) {
        if (key_value_pairs[i].key == key) {
            return key_value_pairs[i].value; // Return the value if key is found
        }
    }
    return NULL; // Key not found
}

int delete(int key) {
    for (int i = 0; i < num_pairs; i++) {
        if (key_value_pairs[i].key == key) {
            // Remove the key-value pair and shift the remaining elements
            for (int j = i; j < num_pairs - 1; j++) {
                key_value_pairs[j] = key_value_pairs[j + 1];
            }
            num_pairs--;
            save_data(); // Save the updated data
            return 1; // Success
        }
    }
    return 0; // Key not found
}
// clears all key-value pairs stored in the key-value store
void clear() {
    num_pairs = 0; // Clear all key-value pairs
    save_data(); // Save the updated data (empty database)
}
// Prints all key-value pairs stored in the key-value store
void print_all() {
    for (int i = 0; i < num_pairs; i++) {
        printf("%d,%s\n", key_value_pairs[i].key, key_value_pairs[i].value); // Print all key-value pairs
    }
}


