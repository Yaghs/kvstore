/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   kvstore.h
 * Author: student
 *
 * Created on October 15, 2023, 11:02 PM
 */

#ifndef KVSTORE_H
#define KVSTORE_H

// Maximum length for key and value
#define MAX_KEY_LENGTH 20
#define MAX_VALUE_LENGTH 100


typedef struct {
    int key;
    char value[MAX_VALUE_LENGTH];
} KeyValue;

void initialize();

int put(int key, const char *value);

char *get(int key);

int delete(int key);

void clear();

void print_all();

#endif

